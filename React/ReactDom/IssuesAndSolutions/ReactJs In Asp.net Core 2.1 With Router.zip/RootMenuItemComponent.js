﻿class RootMenuItem extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            dataList: [],
        };
    }
    componentDidMount() {
        this.getmenuItems();
    }

    getmenuItems() {
        var Tempdata = [{ "mobMenuItemId": "70006", "menuItemName": "Online Payment Stats" },
        { "mobMenuItemId": "70008", "menuItemName": "This Is Testing Menu" }];

        this.setState({ dataList: Tempdata });
    }

    ChooseArticle = () => {
        this.props.history.push('/about');
    };




    render() {
        return (
           
            <div className="row">
                {this.state.dataList.map(item => (
                    <div key={item.mobMenuItemId} className="col-12 text-center" style={{ backgroundColor: 'red', margin: '5px' }}>
                        <h2 onClick={this.ChooseArticle.bind(null)} >  {item.menuItemName}</h2>
                    </div>    
                    ))}
                </div>
               
        );
    }
}


