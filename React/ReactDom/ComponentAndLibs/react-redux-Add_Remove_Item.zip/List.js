import React, { Component } from "react";
import { connect } from "react-redux";
import { deleteArticle } from "../../redux/Actions/Actions";

const mapStateToProps = (state) => {
  return { articles: state.articles };
};

const mapDispatchToProps = (dispatch) => ({
  DeleteFromReduxStore: (MYVal) => dispatch(deleteArticle(MYVal)),
});


class List extends Component {

    constructor(props) {
        super(props);
        this.state = {

        };

        this.handleRemove = this.handleRemove.bind(this);
    }
    
    handleRemove(id) {
    this.props.DeleteFromReduxStore({ id });
      }


  render() {
    return (
      <div>
        <ol>
          {this.props.articles.map((el,index) => (
            <li key={el.id}>
              {el.title}
              <button
                key={el.id}
                type="button"
                onClick={() => this.handleRemove(index)}
              >
                Remove
              </button>
            </li>
          ))}
        </ol>
      </div>
    );
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(List);;
