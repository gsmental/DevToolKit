import { ADD_ARTICLE,ADD_ARTICLE2,DELETE_ARTICLE } from "../ActionTypes/ActionTypes";
const initialState = {
  articles: [],
};

function rootReducer(state = initialState, action) {
  switch (action.type) {
    case ADD_ARTICLE:
         // https://www.valentinog.com/blog/redux/  Search : https://www.valentinog.com/blog/redux/
      return Object.assign({}, state, {
        articles: state.articles.concat(action.payload),
      });
    

      case DELETE_ARTICLE:
        return {
          articles : state.articles.filter( (item, index) => index !== action.payload.id)
       }

    default:
      return state
  }
}




// function rootReducer(state = initialState, action) {
//   if (action.type === ADD_ARTICLE) {
//     // https://www.valentinog.com/blog/redux/  Search : https://www.valentinog.com/blog/redux/

//     return Object.assign({}, state, {
//       articles: state.articles.concat(action.payload),
//     });
//   }
//   return state;
// }

export default rootReducer;
