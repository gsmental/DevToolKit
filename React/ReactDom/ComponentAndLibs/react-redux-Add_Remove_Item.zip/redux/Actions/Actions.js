import {ADD_ARTICLE,ADD_ARTICLE2,DELETE_ARTICLE} from '../ActionTypes/ActionTypes';

export function addArticle(payload) {
  return { type: ADD_ARTICLE, payload };
}

export function deleteArticle(payload) {
    return { type: DELETE_ARTICLE, payload };
  }