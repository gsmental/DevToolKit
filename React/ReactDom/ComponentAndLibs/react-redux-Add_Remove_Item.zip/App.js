import React, { Component } from 'react';
import { connect } from "react-redux";

//redux
import List from '../pages/Lab/List';
import Form from '../pages/Lab/Form';

const App = () => (
    <div>
      <h2>Articles</h2>
        <List />
        <Form/>
    </div>
  );
  
  export default App;
