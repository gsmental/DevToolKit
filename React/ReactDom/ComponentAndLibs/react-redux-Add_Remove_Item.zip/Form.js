import React, { Component } from "react";
import { connect } from "react-redux";
import { addArticle } from '../../redux/Actions/Actions';

function mapDispatchToProps(dispatch) {
  return {
    AddArticleToStore: MYVal => dispatch(addArticle(MYVal))
  };
}

const mapStateToProps = state => {
    return { MyCount: state.articles.length };
  };
  

class ConnectedForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      title: "",
      Delva:"",
    };
    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
 
  }


  handleChange(event) {
    this.setState({ [event.target.id]: event.target.value });
  }

  handleSubmit(event) {
    event.preventDefault();
    const { title } = this.state;
    this.props.AddArticleToStore({ title });
    this.setState({ title: "" });
  }
  render() {
    const { title } = this.state;
    return (
      <form onSubmit={this.handleSubmit}>
        <div>
           
          <label htmlFor="title">Title</label>
          <input
            type="text"
            id="title"
            value={title}
            onChange={this.handleChange} autoComplete="false"
          />
        </div>
        <button type="submit" >SAVE</button> <b style={{color:'red'}}> Total Articles: {this.props.MyCount}</b>
      </form>
    );
  }
}

const Form = connect(
    mapStateToProps,
  mapDispatchToProps
)(ConnectedForm);

export default Form;