﻿class RootMenuItem extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            dataList: [],
        };
    }
    componentDidMount() {
        this.getmenuItems();
    }

    getmenuItems() {
        var Tempdata = [{ "mobMenuItemId": "70006", "menuItemName": "Online Payment Stats" },
        { "mobMenuItemId": "70008", "menuItemName": "This Is Testing Menu" }];

        this.setState({ dataList: Tempdata });
    }

    render() {
        return (
           
            <div className="row">
                {this.state.dataList.map(item => (
                    <div className="col-12 text-center" style={{ backgroundColor: 'red', margin: '5px' }}>
                        <h2>  {item.menuItemName}</h2>
                    </div>    
                    ))}
                </div>
               
        );
    }
}


