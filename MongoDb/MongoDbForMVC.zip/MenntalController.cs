﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NotebookAppApi.Model;
using MongoDB.Bson;
using MongoDB.Driver;

namespace NotebookAppApi.Controllers
{
    public class MenntalController : Controller
    {
        private MongoHelper<Users> _users = new MongoHelper<Users>();

        public IActionResult Index()
        {
            ViewBag.obj = _users.Collection.Find(new BsonDocument()).ToList();

            return View();
        }

        [HttpPost]
        public IActionResult Index(Users post)
        {
            _users.Collection.InsertOne(post);
            return View();
        }


        [HttpGet]
        public IActionResult MyList()
        {
           var obj= _users.Collection.Find(new BsonDocument()).ToList();
            return View();
        }
    }
}