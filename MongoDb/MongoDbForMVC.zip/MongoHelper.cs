﻿using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB;
using MongoDB.Bson.Serialization;

namespace NotebookAppApi.Model
{
    public class MongoHelper<T> where T : class
    {
        public IMongoCollection<T> Collection { get; private set; }

        private IMongoClient _client;
        private IMongoDatabase _database;

        public MongoHelper()
        {
            var connectionString = "mongodb://localhost:27017";
            _client = new MongoClient(connectionString);
            _database = _client.GetDatabase("MenntalDb");
            Collection = _database.GetCollection<T>(typeof(T).Name.ToLower());
        }
    }
}